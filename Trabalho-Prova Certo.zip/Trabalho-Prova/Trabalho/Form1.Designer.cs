﻿namespace Trabalho
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_AbreCar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_AbreCar
            // 
            this.btn_AbreCar.BackColor = System.Drawing.Color.Coral;
            this.btn_AbreCar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_AbreCar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AbreCar.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_AbreCar.Location = new System.Drawing.Point(728, 332);
            this.btn_AbreCar.Name = "btn_AbreCar";
            this.btn_AbreCar.Size = new System.Drawing.Size(72, 118);
            this.btn_AbreCar.TabIndex = 0;
            this.btn_AbreCar.Text = "Ajude nos a montar nosso cardapio, selecione uma categoria.";
            this.btn_AbreCar.UseVisualStyleBackColor = false;
            this.btn_AbreCar.Click += new System.EventHandler(this.btn_AbreCar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Trabalho.Properties.Resources.comidas_trab1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_AbreCar);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_AbreCar;
    }
}

